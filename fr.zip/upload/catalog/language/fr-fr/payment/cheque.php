<?php
// Text
$_['text_title']		= 'Instructions Ch&egrave;que - Mandat postal';
$_['text_instruction']	= 'Instructions pour le ch&egrave;que - Mandat postal';
$_['text_payable']		= 'Payable &Agrave; l&#8217;ordre de :';
$_['text_address']		= '&Agrave; adresser &agrave; :';
$_['text_payment']		= 'Votre commande vous sera livr&eacute;e qu&#8217;apr&egrave;s  r&eacute;ception de votre r&egrave;glement.';
?>