<?php

$_['text_title'] 					= 'Carte de cr&eacute;dit';
$_['button_confirm'] 				= 'Confirmer';

$_['text_postcode_check'] 			= 'Contr&ocirc;le code postal : %s';
$_['text_security_code_check'] 		= 'Contr&ocirc;leCVV2 : %s';
$_['text_address_check'] 			= 'Contr&ocirc;le adresse : %s';
$_['text_not_given'] 				= 'Non communiqu&eacute;';
$_['text_not_checked'] 				= 'Non contr&ocirc;l&eacute;';
$_['text_match'] 					= 'Correspond';
$_['text_not_match'] 				= 'Ne correspond pas';
$_['text_payment_details'] 			= 'D&eacute;tails du paiement';

$_['entry_card_type'] 				= 'Type de la carte';
?>