<?php
// Text
$_['text_title']			= 'Carte de cr&eacute;dit (SagePay)';
$_['text_credit_card']		= 'D&eacute;tails carte de cr&eacute;dit';
$_['text_wait']				= 'Veuillez patienter !';

// Entry
$_['entry_cc_owner']		= 'Propri&eacute;aire de la carte :';
$_['entry_cc_number']		= 'Num&eacute;ro de la carte :';
$_['entry_cc_expire_date']	= 'Date d&#8217;expiration de la carte :';
$_['entry_cc_cvv2']			= 'Code de s&eacute;curit&eacute; de la carte (CVV2):';
?>