<?php
// Text
$_['text_title']			= 'Carte de cr&eacute;dit (Authorize.Net)';
$_['text_credit_card']		= 'D&eacute;tails de la carte de cr&eacute;dit';

// Entry
$_['entry_cc_owner']		= 'Propri&eacute;taire de la carte :';
$_['entry_cc_number']		= 'N&deg; de la carte :';
$_['entry_cc_expire_date']	= 'Date d&#8217;expiration de la carte :';
$_['entry_cc_cvv2']			= 'Code de s&eacute;curit&eacute; de la carte (CVV2) :';
?>