<?php
// Text
$_['text_subject']	= '%s - Nouveau mot de passe';
$_['text_greeting']	= 'Un nouveau mot de passe a &eacute;t&eacute; demand&eacute; pour l&#8217;acc&egrave;s &agrave; %s.';
$_['text_password']	= 'Votre nouveau mot de passe est :';
?>