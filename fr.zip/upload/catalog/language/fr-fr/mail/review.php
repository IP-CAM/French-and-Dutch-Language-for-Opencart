<?php
// Text
$_['text_subject']	= '%s - Avis produit';
$_['text_waiting']	= 'Vous avez un nouvel avis produit en attente.';
$_['text_product']	= 'Produit : %s';
$_['text_reviewer']	= 'Critique : %s';
$_['text_rating']	= 'Taux : %s';
$_['text_review']	= 'Texte de l&#8217;avis :';
?>