<?php
// Text
$_['text_title']	= 'United States Postal Service';
$_['text_weight']	= 'Poids :';
$_['text_eta']		= 'Temps estim&eacute; :';
?>