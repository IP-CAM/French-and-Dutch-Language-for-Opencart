<?php
// Text
$_['text_title']		= 'Taux fixe ';
$_['text_description']	= 'Livraison &agrave; taux fixe ';
?>