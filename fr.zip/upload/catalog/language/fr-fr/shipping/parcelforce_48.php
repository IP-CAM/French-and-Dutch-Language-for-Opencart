<?php
// Text
$_['text_title']		= 'Parcelforce 48';
$_['text_description']	= 'Parcelforce 48';
$_['text_weight']		= ' (Poids : %s)'; 
$_['text_insurance']	= ' (Assur&eacute; &agrave; hauteur de : %s)';   
$_['text_time']			= ' (Temps &Eacute;stim&eacute; : dans les 48 heures)';
?>