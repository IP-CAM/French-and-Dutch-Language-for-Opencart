<?php
// Text
$_['text_title']		= 'Retrait au magasin ';
$_['text_description']	= 'Retrait au magasin ';
?>