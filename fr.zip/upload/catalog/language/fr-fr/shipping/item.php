<?php
// Text
$_['text_title']		= 'Par produit ';
$_['text_description']	= 'Livraison par taux et par produit ';
?>