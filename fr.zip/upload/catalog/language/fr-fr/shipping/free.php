<?php
// Text
$_['text_title']		= 'Livraison gratuite ';
$_['text_description']	= 'Livraison gratuite ';
?>