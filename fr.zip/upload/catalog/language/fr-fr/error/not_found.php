<?php
// Heading
$_['heading_title']	= 'La page requise est introuvable ! ';

// Text
$_['text_error']	= 'La page requise est introuvable.';
?>