<?php
// Heading 
$_['heading_title']		= 'Abonnement &agrave; la lettre d&#8217;information';

// Text
$_['text_account']		= 'Compte';
$_['text_newsletter']	= 'Lettre d&#8217;information';
$_['text_success']		= 'F&eacute;licitations, votre abonnement &agrave; la lettre d&#8217;information a &eacute;t&eacute; mise &agrave; jour avec succ&egrave;s !';

// Entry
$_['entry_newsletter']	= 'S&#8217;abonner :';
?>