<?php
// Heading 
$_['heading_title']		= 'Vos t&eacute;l&eacute;chargements';

// Text
$_['text_account']		= 'Compte';
$_['text_downloads']	= 'T&eacute;l&eacute;chargements';
$_['text_empty']		= 'Vous n&#8217;avez effectu&eacute; aucune commande t&eacute;l&eacute;chargeable ! ';

// Column
$_['column_order_id']   = 'R&eacute;f. commande :';
$_['column_name']       = 'Nom :';
$_['column_size']       = 'Taille :';
$_['column_date_added'] = 'Date d&#8217;ajout :';
?>