<?php
// Heading
$_['heading_title']			= 'Vos points de fid&eacute;lit&eacute;';

// Column
$_['column_date_added']		= 'Date d&#8217;ajout';
$_['column_description']	= 'Description';
$_['column_points']			= 'Points';

// Text
$_['text_account']			= 'Compte';
$_['text_reward']			= 'Points de fid&eacute;lit&eacute;';
$_['text_total']			= 'Votre nombre total de points de fid&eacute;lit&eacute; est de :';
$_['text_empty']			= 'Aucun point de fid&eacute;lit&eacute;.';
?>