<?php
// Text
$_['text_success']     = 'F&eacute;licitations, votre ch&egrave;que-cadeau a &eacute;t&eacute; appliqu&eacute; !';
$_['text_cart']        = 'F&eacute;licitations, vous avez modifi&eacute; votre panier !';

$_['text_for']         = '%s Ch&egrave;que-cadeau pour %s';

// Error
$_['error_permission'] = 'Attention, vous n&#8217;avez pas la permission d&#8217;acc&eacute;s &agrave; l&#8217;API !';
$_['error_voucher']    = 'Attention, le ch&egrave;que-cadeau est soit invalide ou d&eacute;j&agrave; utilis&eacute; !';
$_['error_to_name']    = 'Le nom du destinataire doit &ecirc;tre compos&eacute; de 1 &agrave; 64 caract&egrave;res !';
$_['error_from_name']  = 'Votre nom doit &ecirc;tre compos&eacute; de 1 &agrave; 64 caract&egrave;res !';
$_['error_email']      = 'L&#8217;adresse courriel semble ne pas &ecirc;tre valide !';
$_['error_theme']      = 'Vous devez choisir une occasion !';
$_['error_amount']     = 'Le montant doit &ecirc;tre compris entre %s et %s!';
?>