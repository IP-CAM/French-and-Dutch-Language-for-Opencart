<?php
// Text
$_['text_success']     = 'F&eacute;licitations, votre bon de r&eacute;duction a &eacute;t&eacute; appliqu&eacute; !';

// Error
$_['error_permission'] = 'Attention, vous n&#8217;avez pas la permission d&#8217;acc&eacute;s &agrave;l&#8217;API !';
$_['error_coupon']     = 'Attention, ce bon de r&eacute;duction est soit invalide, soit expir&eacute; ou a atteint sa limite d&#8217;utilisation !';
?>