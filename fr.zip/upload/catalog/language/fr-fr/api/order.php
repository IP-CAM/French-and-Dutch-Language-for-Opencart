<?php
// Text
$_['text_success']           = 'Votre ordre a modifi&eacute; les commandes avec succ&egrave;s';

// Error
$_['error_permission']       = 'Attention, vous n&#8217;avez pas la permission d&#8217;acc&eacute;s &agrave; l&#8217;API !';
$_['error_customer']         = 'Les informations du client doit &ecirc;tre renseign&eacute;es !';
$_['error_payment_address']  = 'Adresse de paiement requis !';
$_['error_payment_method']   = 'Mode de paiement requis !';
$_['error_shipping_address'] = 'Adresse de livraison requise !';
$_['error_shipping_method']  = 'Mode de livraison requis !';
$_['error_stock']            = 'Les produits marqu&eacute;s *** ne sont pas disponible dans la quantit&eacute; demand&eacute;e ou pas en stock!';
$_['error_minimum']          = 'Le montant minimum de la commande pour %s est %s!';
$_['error_not_found']        = 'Attention la commande n&#8217;a pas pu &ecirc;tre trouv&eacute;e !';
?>