<?php
// Text
$_['text_success'] = 'F&eacute;licitations, la session API session a d&eacute;marr&eacute;e avec succ&egrave;s !';

// Error
$_['error_login']  = 'Attention, aucune correspondance pour le nom d&#8217;utilisateur et/ou le mot de passe.';
?>