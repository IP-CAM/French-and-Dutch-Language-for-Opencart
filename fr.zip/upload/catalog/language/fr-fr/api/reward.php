<?php
// Text
$_['text_success']     = 'F&eacute;licitations, vos points de fid&eacute;lit&eacute; ont &eacute;t&eacute; appliqu&eacute;s !';

// Error
$_['error_permission'] = 'Attention, vous n&#8217;avez pas la permission d&#8217;acc&eacute;s &agrave; l&#8217;API !';
$_['error_reward']     = 'Attention, merci d&#8217;indiquer le nombre de points de fid&eacute;lit&eacute; que vous souhaitez utiliser !';
$_['error_points']     = 'Attention, vous n&#8217;avez pas %s points de fid&eacute;lit&eacute; !';
$_['error_maximum']    = 'Attention, le nombre maximum de points applicables est de %s !';
?>