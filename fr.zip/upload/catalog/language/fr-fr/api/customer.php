<?php
// Text
$_['text_success']       = 'Vous avez modifi&eacute; les clients avec succ&egrave;s';

// Error
$_['error_permission']   = 'Attention, vous n&#8217;avez pas la permission d&#8217;acc&eacute;s &agrave; l&#8217;API !';
$_['error_firstname']    = 'Le nom doit &ecirc;tre compos&eacute; de 1 &agrave; 32 caract&egrave;res !';
$_['error_lastname']     = 'Le pr&eacute;nom doit &ecirc;tre compos&eacute; de 1 &agrave; 32 caract&egrave;res !';
$_['error_email']        = 'L&#8217;adresse courriel semble invalide !';
$_['error_telephone']    = 'Le nu&eacute;ro de t&eacute;l&eacute;phone doit &ecirc;tre compos&eacute; de 1 &agrave; 32 caract&egrave;res !';
$_['error_custom_field'] = '%s requis !';
?>