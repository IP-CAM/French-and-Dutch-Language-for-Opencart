<?php
// Text
$_['text_success']     = 'F&eacute;licitations, vous avez modifi&eacute; votre panier !';

// Error
$_['error_permission'] = 'Attention, vous n&#8217;avez pas la permission d&#8217;acc&eacute;s &agrave; l&#8217;API !';
$_['error_stock']      = 'Les produits marqu&eacute;s *** ne sont pas disponible dans la quantit&eacute; souhait&eacute;e ou pas en stock !';
$_['error_minimum']    = 'Le montant minimum de la commande pour for %s est %s!';
$_['error_store']      = 'Le produit ne peut &ecirc;tre achet&eacute; dans cette boutique !';
$_['error_required']   = '%s requis!';
?>