<?php
// Text
$_['text_upload']    = 'Votre fichier a &eacute;t&eacute; t&eacute;l&eacute;charg&eacute; avec succ&egrave;s !';

// Error
$_['error_filename'] = 'Le nom du fichier doit &ecirc;tre compos&eacute; de 3 &agrave; 64 caract&egrave;res !';
$_['error_filetype'] = 'Type de fichier invalide !';
$_['error_upload']   = 'T&eacute;l&eacute;chargement requis !';
?>
