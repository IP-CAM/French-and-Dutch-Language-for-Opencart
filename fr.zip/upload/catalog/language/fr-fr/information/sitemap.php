<?php
// Heading
$_['heading_title']		= 'Plan du site';
 
// Text
$_['text_special']		= 'Promotions';
$_['text_account']		= 'Mon compte';
$_['text_edit']			= 'Informations';
$_['text_password']		= 'Mot de passe';
$_['text_address']		= 'Carnet d&#8217;adresse';
$_['text_history']		= 'Historique';
$_['text_download']		= 'T&eacute;l&eacute;chargements';
$_['text_cart']			= 'Panier';
$_['text_checkout']		= 'Commander';
$_['text_search']		= 'Recherche';
$_['text_information']	= 'Informations';
$_['text_contact']		= 'Nous contacter';
?>