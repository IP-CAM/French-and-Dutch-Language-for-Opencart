<?php
$_['heading_title'] = 'Sur notre boutique eBay';