<?php
// Heading
$_['heading_title']		= 'Meilleures ventes';

// Text
$_['text_tax']		    = 'H.T. :';
?>