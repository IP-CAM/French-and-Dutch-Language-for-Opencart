<?php
// Heading
$_['heading_title']  = 'Conversation en direct';
?>