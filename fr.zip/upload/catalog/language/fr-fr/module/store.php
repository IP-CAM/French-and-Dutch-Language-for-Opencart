<?php
// Heading 
$_['heading_title']	= 'Choisir une boutique';

// Text
$_['text_default']	= 'D&eacute;faut';
$_['text_store']	= 'Veuillez choisir la boutique que vous d&eacute;sirez visiter.';
?>