<?php
// Heading
$_['heading_title']	= 'Recherche avanc&eacute;e';
?>