<?php
// Heading
$_['heading_title']		= 'Affiliation';

// Text
$_['text_register']		= 'Enregistrement';
$_['text_login']		= 'Se connecter';
$_['text_logout']		= 'Se d&eacute;connecter';
$_['text_forgotten']	= 'Mot de passe oubli&eacute;';
$_['text_account']		= 'Mon compte';
$_['text_edit']			= '&Eacute;dition de compte';
$_['text_password']		= 'Mot de passe';
$_['text_payment']		= 'Options paiement';
$_['text_tracking']		= 'Suivi affiliation';
$_['text_transaction']	= 'Transactions';
?>
