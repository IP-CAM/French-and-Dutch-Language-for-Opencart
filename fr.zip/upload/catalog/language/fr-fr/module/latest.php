<?php
// Heading
$_['heading_title']		= 'Nouveaut&eacute;s';

// Text
$_['text_tax']		    = 'H.T. :';
?>