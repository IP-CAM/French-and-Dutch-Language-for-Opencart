<?php
// Text
$_['text_total_shipping']		= 'Livraison';
$_['text_total_discount']		= 'Remise';
$_['text_total_tax']			= 'Taxe';
$_['text_total_sub']			= 'Sous-total';
$_['text_total']				= 'Total';
?>