<?php
// Text
$_['text_paid_amazon'] 			= 'Payer sur Amazon';
$_['text_total_shipping'] 		= 'Livraison';
$_['text_total_shipping_tax'] 	= 'Taxe sur livraison';
$_['text_total_giftwrap'] 		= 'Emballage cadeau';
$_['text_total_giftwrap_tax'] 	= 'Taxe sur emballage cadeau';
$_['text_total_sub'] 			= 'Sous-total';
$_['text_tax'] 					= 'Taxe';
$_['text_total'] 				= 'Total';
?>