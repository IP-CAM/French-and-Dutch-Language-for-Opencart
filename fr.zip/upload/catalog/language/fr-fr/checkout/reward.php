<?php
// Heading
$_['heading_title'] = 'Utiliser vos points de fid&eacute;lit&eacute; (Disponible %s)';

// Text
$_['text_success']  = 'F&eacute;licitations, vos points de fid&eacute;lit&eacute; ont &eacute;t&eacute; appliqu&eacute;s !';

// Entry
$_['entry_reward']  = 'Points utilisables (Max %s)';

// Error
$_['error_reward']  = 'Attention, merci d&#8217;indiquer le nombre de points de fid&eacute;lit&eacute; que vous souhaitez utiliser !';
$_['error_points']  = 'Attention, vous n&#8217;avez pas %s points de fid&eacute;lit&eacute; !';
$_['error_maximum'] = 'Attention, le nombre maximum de points de fid&eacute;lit&eacute; disponible est %s!';
?>