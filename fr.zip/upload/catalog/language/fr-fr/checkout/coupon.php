<?php
// Heading
$_['heading_title'] = 'Utiliser un bon de r&eacute;duction';

// Text
$_['text_success']  = 'F&eacute;licitations, votre bon de r&eacute;duction a &eacute;t&eacute;t appliqu&eacute; !';

// Entry
$_['entry_coupon']  = 'Entrer le code de votre bon de r&eacute;duction ici';

// Error
$_['error_coupon']  = 'Attention, le bon de r&eacute;duction est soit invalide, soit expir&eacute; ou a d&eacute;pass&eacute; sa limite d"8217;utilisation !';
$_['error_empty']   = 'Attention, veuillez entrer un code de bon de r&eacute;duction !';
?>