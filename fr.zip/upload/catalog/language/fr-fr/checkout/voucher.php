<?php
// Heading
$_['heading_title'] = 'Utiliser un ch&egrave;que-cadeau';

// Text
$_['text_success']  = 'F&eacute;licitations, votre ch&egrave;que-cadeau a &eacute;t&eacute; appliqu&eacute; !';

// Entry
$_['entry_voucher'] = 'Entrer le code de votre ch&egrave;que-cadeau ici';

// Error
$_['error_voucher'] = 'Attention, le ch&egrave;que-cadeau est soit invalide, soit la somme a &eacute;t&eacute; d&eacute;j&agrave; utilis&eacute; !';
$_['error_empty']   = 'Attention, indiquez le code de votre ch&egrave;que-cadeau !';
?>