<?php
// Heading
$_['heading_title']		= 'Suivi d&#8217;affiliation';

// Text
$_['text_account']		= 'Compte';
$_['text_description']	= 'Afin d&#8217;assurer votre paiement pour les recommandations que vous nous envoyez, nous avons besoin pour suivre ces recommandations que vous placiez un code de suivi dans les URL pointant vers notre boutique. Vous pouvez utiliser les outils ci-dessous pour g&eacute;n&eacute;rer des liens vers %s.';

// Entry
$_['text_code']			= '<b>Votre code de suivi :</b>';
$_['text_generator']	= '<b>G&eacute;n&eacute;rateur de liens de suivi</b>';
$_['text_link']			= '<b>Lien de suivi :</b>';

// Help
$_['help_generator']   = 'Tapez le nom d&#8217;un produit dont vous souhaitez faire un lien vers';
?>