<?php
// Heading
$_['heading_title']	= 'Se d&eacute;connecter du compte';

// Text
$_['text_message']	= '<p>Vous avez &eacute;t&eacute; d&eacute;connect&eacute; de votre compte. D&eacute;sormais vous pouvez laisser votre ordinateur.</p><p>Votre panier a &eacute;t&eacute; sauvegard&eacute; ainsi que les produits qui s&#8217;y trouvaient. Ils seront restaur&eacute;s la prochaine fois que vous vous connecterez &agrave; votre compte.</p>';
$_['text_account']	= 'Compte';
$_['text_logout']	= 'Se d&eacute;connecter';
?>