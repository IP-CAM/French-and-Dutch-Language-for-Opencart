<?php
// Heading
$_['heading_title']		= 'Maintenance';

// Text
$_['text_maintenance']	= 'Maintenance';
$_['text_message']		= '<h1 style="text-align:center;">Nous sommes actuellement en train de r&eacute;aliser une op&eacute;ration de maintenance.<br />Nous serons de retour d&egrave;s que possible. Veuillez r&eacute;essayer un peu plus tard.</h1>';
?>