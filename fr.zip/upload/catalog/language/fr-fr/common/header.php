<?php
// Text
$_['text_home']			= 'Accueil';
$_['text_wishlist']		= 'Liste de souhaits (%s)';
$_['text_shopping_cart']= 'Panier';
$_['text_category']     = 'Cat&eacute;gories';
$_['text_account']		= 'Compte';
$_['text_register']     = 'S&#8217;enregistrer';
$_['text_login']        = 'Connexion';
$_['text_order']        = 'Historique des commandes';
$_['text_transaction']  = 'Transactions';
$_['text_download']     = 'T&eacute;l&eacute;chargements';
$_['text_logout']       = 'Se d&eacute;connecter';
$_['text_checkout']		= 'Commander';
$_['text_search']		= 'Recherche';
$_['text_all']          = 'Voir tout';
?>