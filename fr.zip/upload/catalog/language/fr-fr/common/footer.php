<?php
// Text
$_['text_information']	= 'Information';
$_['text_service']		= 'Service client';
$_['text_extra']		= 'Extras';
$_['text_contact']		= 'Nous contacter';
$_['text_return']		= 'Retour de marchandise';
$_['text_sitemap']		= 'Plan du site';
$_['text_manufacturer']	= 'Fabricants';
$_['text_voucher']		= 'Ch&egrave;ques-cadeaux';
$_['text_affiliate']	= 'Affiliations';
$_['text_special']		= 'Promotions';
$_['text_account']		= 'Mon compte';
$_['text_order']		= 'Historique de commandes';
$_['text_wishlist']		= 'Liste de souhaits';
$_['text_newsletter']	= 'Lettre d&#8217;information';
$_['text_powered']		= 'D&eacute;velopp&eacute; Par <a href="http://www.opencart.com" onclick="window.open(this.href)">OpenCart</a><br /> %s &copy; %s';
?>