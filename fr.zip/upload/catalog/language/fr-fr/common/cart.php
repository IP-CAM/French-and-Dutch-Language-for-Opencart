<?php
// Text
$_['text_items']      = '%s &eacute;l&eacute;ment(s) - %s';
$_['text_empty']      = 'Votre panier est vide !';
$_['text_cart']       = 'Voir le panier';
$_['text_checkout']   = 'Commander';
$_['text_recurring']  = 'Profil de paiement';
?>