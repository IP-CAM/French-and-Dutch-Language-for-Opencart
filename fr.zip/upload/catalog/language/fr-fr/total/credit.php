<?php
// Text
$_['text_credit']	= 'Cr&eacute;dit boutique ';
$_['text_order_id']	= 'Commande N&deg; : #%s';
?>