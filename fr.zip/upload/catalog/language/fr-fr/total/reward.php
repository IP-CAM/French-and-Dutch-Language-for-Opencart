<?php
// Text
$_['text_reward']	= 'Points de fidelit&eacute; (%s) ';
$_['text_order_id']	= 'Commande N&deg; : #%s';
?>