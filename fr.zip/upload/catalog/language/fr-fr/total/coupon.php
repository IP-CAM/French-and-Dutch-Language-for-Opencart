<?php
// Text
$_['text_coupon']	= 'Bon de r&eacute;duction (%s) ';
?>