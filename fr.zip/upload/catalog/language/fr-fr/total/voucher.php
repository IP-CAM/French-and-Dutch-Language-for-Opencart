<?php
// Text
$_['text_voucher']	= 'Ch&egrave;que-cadeau (%s) ';
?>