<?php
// Text
$_['text_klarna_fee'] = 'Frais Klarna ';
?>