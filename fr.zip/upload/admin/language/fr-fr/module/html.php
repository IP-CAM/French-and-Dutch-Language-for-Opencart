<?php
// Heading
$_['heading_title']     = 'Contenu HTML';

// Text
$_['text_module']       = 'Modules';
$_['text_success']      = 'F&eacute;licitations, vous avez modifi&eacute; le module <b>Contenu HTML</b> avec succ&egrave;s !';
$_['text_edit']         = 'Modifier le module Contenu HTML';

// Entry
$_['entry_heading']     = 'Titre ent&ecirc;';
$_['entry_description'] = 'Contenu';
$_['entry_status']      = '&Eacute;tat';

// Error
$_['error_permission']  = 'Attention, vous n&#8217;avez pas la permission de modifier le module <b>Contenu HTML</b> !';
?>