<?php
// Heading
$_['heading_title']    = 'Bouton Commande PayPal Express';

// Text
$_['text_module']      = 'Modules';
$_['text_success']     = 'F&eacute;licitations, vous avez modifi&eacute; le module <b>Bouton Commande PayPal Express</b> avec succ&egrave;s !';
$_['text_edit']        = 'Modifier le module Bouton Commande PayPal Express';

// Entry
$_['entry_status']     = '&Eacute;tat';

// Error
$_['error_permission'] = 'Attention, vous n&#8217;avez pas la permission de modifier le module <b>Bouton Commande PayPal Express</b> !';
?>