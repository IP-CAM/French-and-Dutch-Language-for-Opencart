<?php
// Heading
$_['heading_title']			= 'Filtre';

// Text
$_['text_module']			= 'Modules';
$_['text_success']			= 'F&eacute;licitations, vous avez modifi&eacute; le module <b>Filtre</b> avec succ&egrave;s !';
$_['text_edit']        		= 'Modifier le module Filtre';

// Entry
$_['entry_status']			= '&Eacute;tat';

// Error
$_['error_permission']		= 'Attention, vous n&#8217;avez pas la permission de modifier le module <b>Filtre</b> !';
?>