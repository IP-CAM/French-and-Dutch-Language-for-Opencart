<?php
// Heading
$_['heading_title']    = 'Bouton de paiement Amazon';

$_['text_module']      = 'Modules';
$_['text_success']     = 'F&eacute;licitations : Vous avez modifi&eacute; le module de paiement Amazon !';
$_['text_edit']        = 'Modifier le module de paiement Amazon';

// Entry
$_['entry_status']     = '&Eacute;tat';

// Error
$_['error_permission'] = 'Attention vous n&#8217;&ecirc;tes pas autoris&eacute; &agrave; modifier le module de paiement Amazon !';
?>