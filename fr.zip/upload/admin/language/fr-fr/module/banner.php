<?php
// Heading
$_['heading_title']			= 'Banni&egrave;res';

// Text
$_['text_module']			= 'Modules';
$_['text_success']			= 'F&eacute;licitations, vous avez modifi&eacute; le module <b>Banni&egrave;res</b> avec succ&egrave;s !';
$_['text_edit']             = 'Modifier le module Banni&egrave;res';

// Entry
$_['entry_banner']			= 'Banni&egrave;re';
$_['entry_dimension']		= 'Dimension (L x H)';
$_['entry_width']           = 'Largeur';
$_['entry_height']          = 'Hauteur';
$_['entry_status']			= '&Eacute;tat';

// Error
$_['error_permission']		= 'Attention, vous n&#8217;avez pas la permission de modifier le module <b>Affiliation</b> !';
$_['error_dimension']		= 'Attention, les dimensions <b>(hauteur et largeur)</b> sont requises ';
?>