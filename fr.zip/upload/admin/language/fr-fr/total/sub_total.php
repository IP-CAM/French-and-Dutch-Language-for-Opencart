<?php
// Heading
$_['heading_title']		= 'Sous-total';

// Text
$_['text_total']		= 'Totaux commande';
$_['text_success']		= 'F&eacute;licitations, vous avez modifi&eacute; le <b>Sous-total</b> avec succ&egrave;s !';
$_['text_edit']         = 'Modifier le sous-total';

// Entry
$_['entry_status']		= '&Eacute;tat';
$_['entry_sort_order']	= 'Classement';

// Error
$_['error_permission']	= 'Attention, vous n&#8217;avez pas la permission de modifier le <b>Sous-total</b> !';
?>