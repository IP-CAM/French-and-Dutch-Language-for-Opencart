<?php
// Heading
$_['heading_title']		= 'Taxes';

// Text
$_['text_total']		= 'Totaux Commande';
$_['text_success']		= 'F&eacute;licitations, vous avez modifi&eacute; les <b>Taxes</b> avec succ&egrave;s !';
$_['text_edit']         = 'Modifier les taxes';

// Entry
$_['entry_status']		= '&Eacute;tat';
$_['entry_sort_order']	= 'Classement';

// Error
$_['error_permission']	= 'Attention, vous n&#8217;avez pas la permission de modifier les <b>Taxes</b> !';
?>