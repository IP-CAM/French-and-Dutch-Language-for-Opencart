<?php
// Heading
$_['heading_title']		= 'Ch&egrave;ques-cadeaux';

// Text
$_['text_total']		= 'Totaux commande';
$_['text_success']		= 'F&eacute;licitations, vous avez modifi&eacute; les <b>Ch&egrave;ques-cadeaux</b> avec succ&egrave;s !';
$_['text_edit']         = 'Modifier les ch&egrave;ques-cadeaux';

// Entry
$_['entry_status']		= '&Eacute;tat :';
$_['entry_sort_order']	= 'Classement :';

// Error
$_['error_permission']	= 'Attention, vous n&#8217;avez pas la permission de modifier les <b>Ch&egrave;ques-cadeaux</b> !';
?>