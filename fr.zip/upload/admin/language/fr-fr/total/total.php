<?php
// Heading
$_['heading_title']		= 'Total';

// Text
$_['text_total']		= 'Totaux Commande';
$_['text_success']		= 'F&eacute;licitations, vous avez modifi&eacute; le <b>Total</b> avec succ&egrave;s !';
$_['text_edit']         = 'Modifier le total';

// Entry
$_['entry_status']		= '&Eacute;tat';
$_['entry_sort_order']	= 'Classement';

// Error
$_['error_permission']	= 'Attention, vous n&#8217;avez pas la permission de modifier le <b>Total</b> !';
?>