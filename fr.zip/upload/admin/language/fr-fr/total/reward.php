<?php
// Heading
$_['heading_title']		= 'Points fidelit&eacute;';

// Text
$_['text_total']		= 'Totaux commande';
$_['text_success']		= 'F&eacute;licitations, vous avez modifi&eacute; les <b>Points fidelit&eacute;</b> avec succ&egrave;s !';
$_['text_edit']         = 'Modifier les points fidelit&eacute;';

// Entry
$_['entry_status']		= '&Eacute;tat :';
$_['entry_sort_order']	= 'Classement :';

// Error
$_['error_permission']	= 'Attention, vous n&#8217;avez pas la permission de modifier les <b>Points fidelit&eacute;</b> !';
?>