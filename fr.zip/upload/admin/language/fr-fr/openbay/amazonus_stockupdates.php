<?php
// Heading
$_['heading_title']        				= 'OpenBay Pro pour Amazon US | Mises &agrave; jour du stock';
$_['text_openbay']						= 'OpenBay Pro';
$_['text_amazon']						= 'Amazon US';

// Text
$_['text_empty']                    	= 'Aucun r&eacute;sultat !';

// Entry
$_['entry_date_start']               	= 'Date de d&eacute;but :';
$_['entry_date_end']                 	= 'Date de fin :';

// Column
$_['column_ref']                      	= 'R&eacute;f&eacute;rence';
$_['column_date_requested']           	= 'Date souhait&eacute;e';
$_['column_date_updated']             	= 'Date de mise &agrave; jour';
$_['column_status']                   	= '&Eacute;tat';
$_['column_sku']                      	= 'R&eacute;f&eacute;rence SKU sur Amazon US';
$_['column_stock']                    	= 'Stock';
?>