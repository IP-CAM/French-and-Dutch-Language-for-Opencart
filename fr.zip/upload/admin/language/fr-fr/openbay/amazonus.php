<?php
// Heading
$_['heading_title']         		= 'Amazon USA';
$_['text_openbay']					= 'OpenBay Pro';
$_['text_dashboard']				= 'Tableau de bord Amazon USA';

// Text
$_['text_heading_settings'] 		= 'Param&egrave;tres';
$_['text_heading_account'] 			= 'Changer le plan';
$_['text_heading_links'] 			= 'Liens des articles';
$_['text_heading_register'] 		= 'Souscription';
$_['text_heading_bulk_listing'] 	= 'Annonces';
$_['text_heading_stock_updates'] 	= 'Mises &agrave; jour stock';
$_['text_heading_saved_listings'] 	= 'Annonces sauvegard&eacute;es';
$_['text_heading_bulk_linking'] 	= 'Lien des annonces';
?>