<?php
// Heading
$_['heading_title']         		= 'Etsy';
$_['text_openbay']					= 'OpenBay Pro';
$_['text_dashboard']				= 'Tableau de bord Etsy';

// Messages
$_['text_success']         			= 'Vous avez sauvegard&eacute; vos modifications Etsy.';
$_['text_heading_settings']         = 'Param&egrave;tres';
$_['text_heading_sync']             = 'Synchroniser';
$_['text_heading_register']         = 'S&#8217;enregistrer ici';
$_['text_heading_products']        	= 'Liens des produits';
$_['text_heading_listings']        	= 'Annonces Etsy';

// Errors
$_['error_generic_fail']			= 'Erreur inconnue !';
$_['error_permission']				= 'Vous n&#8217;avez pas la permission de param&eacute;trer Etsy.';
?>