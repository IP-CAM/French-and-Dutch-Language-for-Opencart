<?php
// Headings
$_['heading_title']             = 'eBay - Usage';
$_['text_openbay']              = 'OpenBay Pro';
$_['text_ebay']                 = 'eBay';

// Errors
$_['error_ajax_load']      		= 'D&eacute;sol&eacute;, impossible d&#8217;obtenir une r&eacute;ponse. Essayer plus tard.';
?>