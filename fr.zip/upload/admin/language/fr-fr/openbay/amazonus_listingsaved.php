<?php
// Heading
$_['heading_title'] 				= 'OpenBay Pro pour Amazon US | Annonces sauvegard&eacute;es';
$_['text_openbay'] 					= 'OpenBay Pro';
$_['text_amazon'] 					= 'Amazon US';

// Text
$_['text_description']              = 'Il s&#8217;agit de la liste des annonces de produits enregistr&eacute;es localement et qui sont pr&ecirc;ts &agrave; &ecirc;tre t&eacute;l&eacute;charg&eacute; sur Amazon.';
$_['text_uploaded_alert']           = 'Annonces sauvegard&eacute;es t&eacute;l&eacute;charg&eacute;es !';
$_['text_delete_confirm']           = '&Eacute;tes-vous s&ucirc;r ?';
$_['text_complete']           		= 'Annonces t&eacute;l&eacute;charg&eacute;es';

// Column
$_['column_name']              		= 'Nom';
$_['column_model']             		= 'Mod&egrave;le';
$_['column_sku']               		= 'R&eacute;f&eacute;rence SKU';
$_['column_amazon_sku']        		= 'R&eacute;f&eacute;rence SKU de l&#8217;article sur Amazon US';
$_['column_action']           		= 'Action';
?>