<?php
// Heading
$_['heading_title']					= 'Amazon (EU)';
$_['text_openbay']					= 'OpenBay Pro';
$_['text_dashboard']				= 'Tableau de bord Amazon EU';

// Text
$_['text_heading_settings'] 		= 'Param&egrave;tres';
$_['text_heading_account'] 			= 'Changement de plan';
$_['text_heading_links'] 			= 'Lien annonces';
$_['text_heading_register'] 		= 'Enregistrement';
$_['text_heading_bulk_listing'] 	= 'Liste des liens en nombre';
$_['text_heading_stock_updates'] 	= 'Mise &agrave; jour stock';
$_['text_heading_saved_listings'] 	= 'Sauvegarder les listes';
$_['text_heading_bulk_linking'] 	= 'Liens en nombre';
?>