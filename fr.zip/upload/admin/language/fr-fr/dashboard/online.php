<?php
// Heading
$_['heading_title'] = 'Internautes en ligne';

// Text
$_['text_view']     = 'Voir d&eacute;tails...';
?>