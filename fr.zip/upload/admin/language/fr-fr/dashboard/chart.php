<?php
// Heading
$_['heading_title'] = 'Statistique des ventes';

// Text
$_['text_order']    = 'Commandes';
$_['text_customer'] = 'Clients';
$_['text_day']      = 'Aujourd&#8217;ui';
$_['text_week']     = 'Semaine';
$_['text_month']    = 'Mois';
$_['text_year']     = 'Ann�e';
?>