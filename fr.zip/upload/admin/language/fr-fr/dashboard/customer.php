<?php
// Heading
$_['heading_title'] = 'Clients';

// Text
$_['text_view'] = 'Voir d&eacute;tails...';
?>