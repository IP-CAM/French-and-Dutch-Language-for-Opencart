<?php
// Heading
$_['heading_title'] = 'Ventes';

// Text
$_['text_view']     = 'Voir d&eacute;tails...';
?>