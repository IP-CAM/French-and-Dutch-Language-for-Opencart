<?php
// Heading
$_['heading_title']     = 'Derni&egrave;res commandes';

// Column
$_['column_order_id']   = 'ID commande';
$_['column_customer']   = 'Client';
$_['column_status']     = '&Eacute;tat';
$_['column_total']      = 'Total';
$_['column_date_added'] = 'Date';
$_['column_action']     = 'Action';
?>