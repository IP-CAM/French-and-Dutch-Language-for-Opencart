<?php
// Heading
$_['heading_title'] = 'Carte';

$_['text_order']    = 'Commandes';
$_['text_sale']     = 'Ventes';
?>