<?php
// Heading
$_['heading_title']		= 'Rapport sur les bons de r&eacute;duction';

// Text
$_['text_list']        = 'Liste des bons de r&eacute;duction';

// Column
$_['column_name']		= 'Nom du bon de r&eacute;duction';
$_['column_code']		= 'Code';
$_['column_orders']		= 'Commandes';
$_['column_total']		= 'Total';
$_['column_action']		= 'Action';

// Entry
$_['entry_date_start']	= 'Date de d&eacute;but :';
$_['entry_date_end']	= 'Date de fin :';
?>