<?php
// Heading
$_['heading_title']		= 'Rapport sur les clients en ligne';

// Text 
$_['text_list']         = 'Liste des clients en ligne';
$_['text_guest']        = 'Invit&eacute;';
 
// Column
$_['column_ip']         = 'IP';
$_['column_customer']   = 'Client';
$_['column_url']        = 'Derni&egrave;re page visit&eacute;e';
$_['column_referer']    = 'R&eacute;f&eacute;rant';
$_['column_date_added'] = 'Dernier clic';
$_['column_action']     = 'Action';

// Entry
$_['entry_ip']          = 'IP';
$_['entry_customer']    = 'Client';
?>