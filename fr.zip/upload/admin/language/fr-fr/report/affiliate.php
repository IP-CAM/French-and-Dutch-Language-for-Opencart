<?php
// Heading
$_['heading_title']     = 'Rapport des commissions d&#8217;affili&eacute;s';

// Text
$_['text_list']         = 'Liste des commissions affili&eacute;s';

// Column
$_['column_affiliate']  = 'Nom affili&eacute;';
$_['column_email']      = 'Courriel';
$_['column_status']     = '&Eacute;tat';
$_['column_commission'] = 'Commission';
$_['column_orders']     = 'N&deg; commandes';
$_['column_total']      = 'Total';
$_['column_action']     = 'Action';

// Entry
$_['entry_date_start']  = 'Date de d&eacute;but';
$_['entry_date_end']    = 'Date de fin';
?>