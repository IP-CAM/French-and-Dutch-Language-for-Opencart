<?php
// Heading
$_['heading_title']    = 'Rapport des campagnes marqueting';

// Text
$_['text_list']         = 'Liste des campagnes marqueting';
$_['text_all_status']   = 'Tous les &eacute;tats';

// Column
$_['column_campaign']  = 'Nom de la campagne';
$_['column_code']      = 'Code';
$_['column_clicks']    = 'Clicks';
$_['column_orders']    = 'N&deg; de commandes';
$_['column_total']     = 'Total';

// Entry
$_['entry_date_start'] = 'Date de d&eacute;but';
$_['entry_date_end']   = 'Date de fin';
$_['entry_status']     = '&Eacute;tat de la commande';
?>