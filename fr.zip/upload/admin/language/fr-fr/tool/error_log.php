<?php
// Heading
$_['heading_title']		= 'Journal d&#8217;erreurs';

// Text
$_['text_success']		= 'F&eacute;licitations, vous avez effac&eacute; les entr&eacute;es du <b>Journal d&#8217;erreurs</b> avec succ&egrave;s !';
$_['text_list']         = 'Liste des erreurs';

// Error
$_['error_warning']	   = 'Attention, Votre fichier d&#8217;erreurs %s est %s!';
$_['error_permission'] = 'Attention, vous n&#8217;avez pas la permission de vider le fichier d&#8217;erreurs !';
?>