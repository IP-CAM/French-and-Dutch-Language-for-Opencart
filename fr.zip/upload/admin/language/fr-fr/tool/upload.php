<?php
// Heading
$_['heading_title']     = 'T&eacute;l&eacute;chargements';

// Text
$_['text_success']      = 'F&eacute;licitations, vous avez modifi&eacute; le module <b>T&eacute;l&eacute;chargement</b> !';
$_['text_list']         = 'Liste des t&eacute;l&eacute;chargements';

// Column
$_['column_name']       = 'Nom du t&eacute;l&eacute;chargement';
$_['column_filename']   = 'Nom du fichier';
$_['column_date_added'] = 'Date Ajout';
$_['column_action']     = 'Action';

// Entry
$_['entry_name']        = 'Nom du t&eacute;l&eacute;chargement';
$_['entry_filename']    = 'Nom du fichier';
$_['entry_date_added'] 	= 'Date Ajout';

// Error
$_['error_permission']  = 'Attention, vous n&#8217;avez pas la permission de modifier le module T&eacute;l&eacute;chargement !';
?>