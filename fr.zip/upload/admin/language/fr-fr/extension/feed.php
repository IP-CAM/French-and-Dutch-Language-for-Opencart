<?php
// Heading
$_['heading_title']		= 'Flux de produits';

// Text
$_['text_success']      = 'Bravo : vous avez modifi&eacute; le flux de produits !';
$_['text_list']         = 'Liste des flux';

// Column
$_['column_name']		= 'Nom du flux de produits';
$_['column_status']		= '&Eacute;tat';
$_['column_action']		= 'Action';

// Error
$_['error_permission']  = 'Attention, vous n&#8217;avez la permission de modifier le <b>Flux de produits</b> !';
?>