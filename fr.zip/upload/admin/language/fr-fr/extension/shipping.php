<?php
// Heading
$_['heading_title']		= 'Livraisons';

// Text
$_['text_success']      = 'F&eacute;licitation : Vous avez modifi&eacute; les <b>Livraisons</b> !';
$_['text_list']         = 'Liste des modes de livraison';

// Column
$_['column_name']		= 'Mode de livraison';
$_['column_status']		= '&Eacute;tat';
$_['column_sort_order']	= 'Classement';
$_['column_action']		= 'Action';

// Error
$_['error_permission']	= 'Attention, vous n&#8217;avez la permission de modifier les <b>Modes de livraisons</b> !';
?>