<?php
// Heading
$_['heading_title']		= 'Total commande';

// Text
$_['text_success']      = 'F&eacute;licitation : Vous avez modifi&eacute; <b>Total commande</b> !';
$_['text_list']         = 'Liste des totaux commandes';

// Column
$_['column_name']		= 'Total commande';
$_['column_status']		= '&Eacute;tat';
$_['column_sort_order']	= 'Classement';
$_['column_action']		= 'Action';

// Error
$_['error_permission']	= 'Attention, vous n&#8217;avez la permission de modifier le <b>Total commande</b> !';
?>