<?php
// Heading
$_['heading_title']		= 'Modules';

// Text
$_['text_success']      = 'F&eacute;licitation : Vous avez modifi&eacute; modules !';
$_['text_layout']       = 'Apr&egrave;s avoir install&eacute; et configur&eacute; un module, vous pouvez l&#8217;ajouter &agrave; une mise en page <a href="%s" class="alert-link">ici</a>!';
$_['text_list']         = 'Liste des modules';

// Column
$_['column_name']		= 'Nom du module';
$_['column_action']		= 'Action';

// Error
$_['error_permission']	= 'Attention, vous n&#8217;avez la permission de modifier les <b>Modules</b> !';
?>