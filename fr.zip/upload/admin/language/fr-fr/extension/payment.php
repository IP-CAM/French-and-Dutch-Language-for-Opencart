<?php
// Heading
$_['heading_title']		= 'Paiements';

// Text
$_['text_success']      = 'F&eacute;licitation : Vous avez modifi&eacute; les <b>Paiements</b> !';
$_['text_list']         = 'Liste des paiements';

// Column
$_['column_name']		= 'Mode de paiement';
$_['column_status']		= '&Eacute;tat';
$_['column_sort_order']	= 'Classement';
$_['column_action']		= 'Action';

// Error
$_['error_permission']	= 'Attention, vous n&#8217;avez la permission de modifier les <b>Paiements</b> !';
?>