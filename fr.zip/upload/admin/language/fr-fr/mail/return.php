<?php
// Text
$_['text_subject']			= '%s - Mise &agrave; jour du retour %s';
$_['text_return_id']		= 'Num&eacute;ro de retour:';
$_['text_date_added']		= 'Date de retour :';
$_['text_return_status']	= 'Votre retour a &eacute;t&eacute; mis &agrave; avec l&#8217;&eacute;tat suivant:';
$_['text_comment']			= 'Les commentaires pour ce retour sont :';
$_['text_footer']			= 'Veuillez r&eacute;pondre &agrave; ce message si vous avez des questions.';
?>