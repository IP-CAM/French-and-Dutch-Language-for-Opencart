<?php
// Text
$_['text_subject']	= 'Vous venez de recevoir un ch&egrave;que-cadeau provenant de %s';
$_['text_greeting']	= 'F&eacute;licitations, Vous venez de recevoir un ch&egrave;que-cadeau d&#8217;une valeur de %s';
$_['text_from']		= 'Ce ch&egrave;que-cadeau a &eacute;t&eacute; envoy&eacute; de la part de %s';
$_['text_message']	= 'Avec le message suivant';
$_['text_redeem']	= 'Pour &eacute;changer ce ch&egrave;que-cadeau, notez bien le code de rachat qui est <b>%s</b>.Cliquer ensuite sur le lien ci-dessous et acheter le produit pour lequel vous souhaitez utiliser ce ch&egrave;que-cadeau. Vous pouvez entrer le code de ch&egrave;que-cadeau sur la page du panier avant de valider la commande.';
$_['text_footer']	= 'Si vous avez des questions, veuillez r&eacute;pondre &agrave; ce message.';
?>