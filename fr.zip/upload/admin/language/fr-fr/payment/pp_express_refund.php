<?php
// Heading
$_['heading_title']				= 'Transaction du remboursement';

// Text
$_['text_pp_express']           = 'Commande PayPal Express';
$_['text_current_refunds']      = 'Les remboursements ont d&eacute;j&agrave; &eacute;t&eacute; effectu&eacute;s pour cette transaction. Le remboursement maximum est de';
// Entry
$_['entry_transaction_id']      = 'N&deg; de transaction';
$_['entry_full_refund']         = 'Remboursement int&eacute;gral';
$_['entry_amount']              = 'Compte';
$_['entry_message']             = 'Message';

// Button
$_['button_refund']             = 'Issue du remboursement';

// Error
$_['error_partial_amt']         = 'Vous devez entrer un montant de remboursement partiel';
$_['error_data']                = 'Dans la demande les donn&eacute;es sont manquantes';
?>