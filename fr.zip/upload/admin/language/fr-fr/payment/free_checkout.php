<?php
// Heading
$_['heading_title']			= 'Commande gratuite';

// Text
$_['text_payment']			= 'Paiement';
$_['text_success']			= 'F&eacute;licitations, vous avez modifi&eacute; les d&eacute;tails de la <b>Commande gratuite</b> avec succ&egrave;s !';
$_['text_edit']             = 'Modifier Commande gratuite';

// Entry
$_['entry_order_status']	= '&Eacute;tat de la commande :';
$_['entry_status']			= '&Eacute;tat :';
$_['entry_sort_order']		= 'Classement :';

// Error
$_['error_permission']		= 'Attention, vous n&#8217;avez pas la permission de modifier le paiement <bCommande gratuite</b> !';
?>