<?php
// Heading
$_['heading_title']		= 'Page introuvable !';

// Text
$_['text_not_found']	= 'La page que vous recherchez n&#8217;a pas pu &ecirc;tre trouv&eacute;e ! Veuillez contacter votre administrateur si le probl&egrave;me persiste.';
?>