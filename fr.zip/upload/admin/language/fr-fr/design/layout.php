<?php
// Heading
$_['heading_title']		= 'Dispositions';

// Text
$_['text_success']		  = 'F&eacute;licitations, vous avez sauvegard&eacute; les <b>Dispositions</b> avec succ&egrave;s !';
$_['text_list']           = 'Liste des disposition';
$_['text_add']            = 'Ajouter une disposition';
$_['text_edit']           = 'Modifier une disposition';
$_['text_default']		  = 'D&eacutefaut';
$_['text_content_top']    = 'Haut de page';
$_['text_content_bottom'] = 'Bas de page';
$_['text_column_left']    = 'Colonne gauche';
$_['text_column_right']   = 'Colonne droite';

// Column
$_['column_name']		= 'Nom de la disposition';
$_['column_action']		= 'Action';

// Entry
$_['entry_name']		= 'Nom de la disposition :';
$_['entry_store']		= 'Boutique';
$_['entry_route']		= 'Chemin';
$_['entry_module']      = 'Module';
$_['entry_position']    = 'Position';
$_['entry_sort_order']  = 'Classement';

// Error
$_['error_permission']	= 'Attention, vous n&#8217;avez pas la permission de modifier les <b>Dispositions</b> !';
$_['error_name']		= 'Le <b>Nom de la disposition</b> doit &ecirc;tre compos&eacute; de 3 &agrave; 64 caract&egrave;res !';
$_['error_default']		= 'Attention, cette disposition ne peut pas &ecirc;tre supprim&eacute;e car elle est actuellement affect&eacute;e comme disposition par d&eacutefaut pour cette boutique !';
$_['error_store']		= 'Attention, cette disposition ne peut pas &ecirc;tre supprim&eacute;e car elle est actuellement affect&eacute;e &agrave; %s boutiques !';
$_['error_product']		= 'Attention, cette disposition ne peut pas &ecirc;tre supprim&eacute;e car elle est actuellement affect&eacute;e &agrave; %s produits !';
$_['error_category']	= 'Attention, cette disposition ne peut pas &ecirc;tre supprim&eacute;e car elle est actuellement affect&eacute;e &agrave; %s cat&eacutegories !';
$_['error_information']	= 'Attention, cette disposition ne peut pas &ecirc;tre supprim&eacute;e car elle est actuellement affect&eacute;e &agrave; %s pages d&#8217;information !';
?>