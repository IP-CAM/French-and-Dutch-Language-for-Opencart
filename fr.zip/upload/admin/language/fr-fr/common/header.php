<?php
// Heading
$_['heading_title']		   = 'Administration';

// Text
$_['text_order']		   = 'Commandes';
$_['text_order_status']    = '&Eacute;tats des commandes';
$_['text_complete_status'] = 'Termin&eacute;';
$_['text_customer']        = 'Clients';
$_['text_online']          = 'Clients en ligne';
$_['text_approval']        = 'Approuv&eacute;';
$_['text_product']         = 'Produits';
$_['text_stock']           = 'Hors stock';
$_['text_review']          = 'Avis';
$_['text_return']          = 'Retours';
$_['text_affiliate']	   = 'Affiliations';
$_['text_store']           = 'Boutiques';
$_['text_front']           = 'Boutique';
$_['text_help']            = 'Aide';
$_['text_homepage']        = 'Accueil';
$_['text_support']         = 'Forum officiel';
$_['text_documentation']   = 'Documentation';
$_['text_logout']          = 'D&eacute;connexion';
?>