<?php
// Text
$_['text_footer']	= '<a href="http://www.opencart.com" target="_blank">OpenCart</a> &copy; 2009-' . date('Y') . ' Tous droits r&eacute;serv&eacute;s.';
$_['text_version'] 	= 'Version %s'
?>