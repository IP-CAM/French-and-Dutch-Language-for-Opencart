<?php
$_['text_complete_status']   = 'Commandes termin&eacute;es'; 
$_['text_processing_status'] = 'Commandes en cours'; 
$_['text_other_status']      = 'Autres &Eacute;tats';
?> 