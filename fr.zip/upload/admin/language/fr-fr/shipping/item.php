<?php
// Heading
$_['heading_title']		= 'Par Article';

// Text
$_['text_shipping']		= 'Livraison';
$_['text_success']		= 'F&eacute;licitations, vous avez modifi&eacute; la livraison <b>Par article</b> avec succ&egrave;s !';
$_['text_edit']         = 'Modifier livraison par article';

// Entry
$_['entry_cost']		= 'Co&ucirc;t :';
$_['entry_tax_class']	= 'Classe de taxes :';
$_['entry_geo_zone']	= 'Zone g&eacute;ographique :';
$_['entry_status']		= '&Eacute;tat :';
$_['entry_sort_order']	= 'Classement :';

// Error
$_['error_permission']	= 'Attention, vous n&#8217;avez pas la permission de modifier la livraison <b>Par article</b> !';
?>