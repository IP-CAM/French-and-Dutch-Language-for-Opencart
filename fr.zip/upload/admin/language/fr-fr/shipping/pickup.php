<?php
// Heading
$_['heading_title']		= 'Retrait au Magasin';

// Text 
$_['text_shipping']		= 'Livraison';
$_['text_success']		= 'F&eacute;licitations, vous avez modifi&eacute; le <b>Retrait au Magasin</b> avec succ&egrave;s !';
$_['text_edit']         = 'Modifier le retrait au magasin';

// Entry
$_['entry_geo_zone']	= 'Zone g&eacute;ographique :';
$_['entry_status']		= '&Eacute;tat :';
$_['entry_sort_order']	= 'Classement :';

// Error
$_['error_permission']	= 'Attention, vous n&#8217;avez pas la permission de modifier le <b>Retrait au Magasin</b> !';
?>