<?php
// Heading
$_['heading_title']	  = 'OpenBay Pro';

// Text
$_['text_module']    = 'Modules';
$_['text_installed'] = 'Le module OpenBay Pro est maintenant install&eacute;. Il est disponible dans les Extensions-> OpenBay Pro';
?>