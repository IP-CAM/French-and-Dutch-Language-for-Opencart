<?php
// Heading
$_['heading_title']		= 'Google Base';

// Text
$_['text_feed']			= 'Flux des produits';
$_['text_success']		= 'F&eacute;licitations, vous avez modifi&eacute; le flux <b>Google Base</b> avec succ&egrave;s !';
$_['text_list']         = 'Liste des dispositions';

// Entry
$_['entry_status']		= '&Eacute;tat :';
$_['entry_data_feed']	= 'Adresse URL des donn&eacute;es du flux :<br/><span class="help">Cette URL pointe vers votre flux. Collez-le dans votre serveur de flux.</span>';

// Error
$_['error_permission']	= 'Attention, vous n&#8217;avez pas la permission de modifier l&#8217;url du flux <b>Google Base feed<:b> !';
?>