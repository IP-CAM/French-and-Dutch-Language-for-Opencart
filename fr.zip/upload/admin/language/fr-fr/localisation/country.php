<?php
// Heading
$_['heading_title']				= 'Pays';

// Text
$_['text_success']				= 'F&eacute;licitations, vous avez modifi&eacute; le <b>Pays</b> avec succ&egrave;s !';
$_['text_list']                 = 'Liste des pays';
$_['text_add']                  = 'Ajouter un pays';
$_['text_edit']                 = 'Modifier un pays';

// Column
$_['column_name']				= 'Nom du Pays';
$_['column_iso_code_2']			= 'Code ISO (2)';
$_['column_iso_code_3']			= 'Code ISO (3)';
$_['column_action']				= 'Action';

// Entry
$_['entry_name']				= 'Nom du pays :';
$_['entry_iso_code_2']			= 'Code ISO (2) :';
$_['entry_iso_code_3']			= 'Code ISO (3) :';
$_['entry_address_format']      = 'Format de l&#8217;adresse';
$_['entry_postcode_required']   = 'Code postal requis';
$_['entry_status']              = 'Status';

// Help
$_['help_address_format']       = 'Pr&eacute;nom = {firstname} < br / > nom = {nom} < br / > soci&eacute;t&eacute; = {entreprise} < br / > adresse 1 = {address_1} < br / > adresse 2 = {address_2} < br / > ville = {ville} < br / > Code postal = {code postal} < br / > Zone = {zone} < br / > Zone Code = {zone_code} < br / > pays = {country}';

// Error
$_['error_permission']			= 'Attention, vous n&#8217;avez pas la permission de modifier le <b>Pays</b> !';
$_['error_name']				= 'Le <b>Nom du pays</b> doit &ecirc;tre compos&eacute; de 3 &agrave; 128 caract&egrave;res !';
$_['error_default']				= 'Attention, ce pays ne peut &ecirc;tre supprim&eacute; car il est assign&eacute; comme pays par d&eacute;faut de la boutique !';
$_['error_store']				= 'Attention, ce pays ne peut &ecirc;tre supprim&eacute; car il est assign&eacute; &agrave; %s boutiques!';
$_['error_address']				= 'Attention, ce pays ne peut &ecirc;tre supprim&eacute; car il est assign&eacute; &agrave; %s entr&eacute;es dans le carnet d&#8217;adresses !';
$_['error_affiliate']			= 'Attention, ce pays ne peut &ecirc;tre supprim&eacute; car il est assign&eacute; &agrave; %s affili&eacute;s !';
$_['error_zone']				= 'Attention, ce pays ne peut &ecirc;tre supprim&eacute; car il est assign&eacute; &agrave; %s zones !';
$_['error_zone_to_geo_zone']	= 'Attention, ce pays ne peut &ecirc;tre supprim&eacute; car il est assign&eacute; &agrave; %s zones g&eacute;ographiques !';
?>